#!/bin/bash

##
#
#   Copyright 2012 Alex Vesev
#   
#   This script is a tool to compare files or directories.
#
#   This script is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
# 
#   This script is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
# 
#   You should have received a copy of the GNU General Public License
#   along with this script. If not, see <http://www.gnu.org/licenses/>.
#   
##

${fm_import} # Import file manager variables.

guiCompareUtilityBin="komparator4" # GUI tool to be used for comparision. Binary name to be launched.

targetDirectoriesList=""
minimumQuantityOfDirsToBeCompared="1" # You may load only one directory for comparision, and select another one in external utility UI.
maximumQuantityOfDirsToBeCompared="2"

minPanelNumber="1" # Panel's coordinate system ancors.
maxPanelNumber="4"

errorState="0" # Zero is OK.
errorMisc="1"

quantityOfFoundDirectories="0" # Quantity of directories to be choosen for comparision.
pairOfInListFirstVisiblePanelsNumbers="" # ...

function validatePanelNumber {
    local panelNumber=${1}
    if [ ${panelNumber} -lt ${minPanelNumber} ] \
        || [ ${panelNumber} -gt ${maxPanelNumber} ]
    then
        echo "ERROR:${0}:${LINENO}: Panel number '${panelNumber}' is out of range." >&2
        exit ${errorMisc}
    fi
}

function getDirNamesOnPanels {
    local panelNumberList=("${@}")
    local panelNumberValue=""
    local targetNameFromPanel=""
    local objectNameAsString=""
    local arrayLength=""
    local targetNameFromPanelIdx=""
    local haveSelectedDirNames=""

    for panelNumberValue in "${panelNumberList[@]}" ; do

        haveSelectedDirNames="false"

        # Visibility check
        [ -z "${fm_pwd_panel[panelNumberValue]}" ] \
            && continue

        validatePanelNumber "${panelNumberValue}" # ?!
        objectNameAsString="#fm_panel${panelNumberValue}_files[@]"
        arrayLength="$( eval echo "\${${objectNameAsString}}" )"
        objectNameAsString=""
        for (( targetNameFromPanelIdx=0 ; \
                targetNameFromPanelIdx<arrayLength ; \
                targetNameFromPanelIdx++ ))
        do
            [ "${quantityOfFoundDirectories}" -ge "${maximumQuantityOfDirsToBeCompared}" ] \
                && break
            objectNameAsString="fm_panel${panelNumberValue}_files[targetNameFromPanelIdx]"
            targetNameFromPanel="${!objectNameAsString}"
            [ ! -d "${targetNameFromPanel}" ] \
                && continue
            (( quantityOfFoundDirectories++ ))
            targetDirectoriesList[quantityOfFoundDirectories-1]="${targetNameFromPanel}"
            haveSelectedDirNames="true"
        done
        
        if [ "${haveSelectedDirNames}" == "false" ] ; then
            (( quantityOfFoundDirectories++ ))
            targetDirectoriesList[quantityOfFoundDirectories-1]="${fm_pwd_panel[panelNumberValue]}"
        fi    
    done

    return ${quantityOfFoundDirectories}
}

function getDirNamesToBeCompared {
    local quantityOfFoundTargetDirs=""
    local activePanel=""
    
    local returnCodeSuccess="0"
    local returnCodeErrorMisc="1"
    
    activePanel="${fm_panel}"
    
    case "${activePanel}" in
    1)
        getDirNamesOnPanels 1 2 3 4
    ;;
    2)
        getDirNamesOnPanels 2 1 3 4
    ;;
    3)
        getDirNamesOnPanels 3 4 1 2
    ;;
    4)
        getDirNamesOnPanels 4 3 1 2
    ;;
    *)
        return ${returnCodeErrorMisc}
    ;;
    esac
    
    return ${returnCodeSuccess}
}

#
 #
# #
 #
#

if getDirNamesToBeCompared ; then
    nohup "${guiCompareUtilityBin}" "${targetDirectoriesList[@]}" >/dev/null 2>/dev/null &
else
    echo "ERROR:${0}:${LINENO}: Failed to obtain names to be compared." >&2
    errorState=${errorMisc}
fi

exit ${errorState}

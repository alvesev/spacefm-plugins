#!/bin/bash

##
#
#   Copyright 2012 Alex Vesev
#   
#   This script is a tool to compare files or directories.
#
#   This script is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
# 
#   This script is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
# 
#   You should have received a copy of the GNU General Public License
#   along with this script. If not, see <http://www.gnu.org/licenses/>.
#   
##

${fm_import} # Import file manager variables.

declare -r guiRenameUtilityBin="krename" # GUI tool to be used for comparision. Binary name to be launched.
#declare -r guiRenameUtilityBin="gprename" # GUI tool to be used for comparision. Binary name to be launched.

declare    errorState=0 # Zero is OK.
declare -r errorMisc="1"

function isDependencyOnBoard {
    local returnCodeSuccess="0"
    if ! which "${guiRenameUtilityBin}" > /dev/null ; then
        echo "ERROR:${0}:${LINENO}: Not found renamer exectutable file '${guiRenameUtilityBin}'." >&2
        exit ${errorMisc}
    fi
    return ${returnCodeSuccess}
}
function isEnoughFilesSelected {
    local returnCodeSuccess="0"
    if [ ${#fm_filenames[@]} -lt 1 ] ; then
        echo "Not enough files selected. Select some files and try again." >&2
        exit ${errorMisc}
    fi
    return ${returnCodeSuccess}
}

#
 #
# #
 #
#

isDependencyOnBoard
isEnoughFilesSelected
nohup "${guiRenameUtilityBin}" "${fm_filenames[@]}" 1>/dev/null 2>/dev/null &
exit ${?}

#!/bin/bash

##
#
#   Copyright 2012 Alex Vesev
#   
#   This script is a tool to compare files or directories.
#
#   This script is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
# 
#   This script is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
# 
#   You should have received a copy of the GNU General Public License
#   along with this script. If not, see <http://www.gnu.org/licenses/>.
#   
##

${fm_import} # Import file manager variables.

guiCompareUtilityBin="komparator4" # GUI tool to be used for comparision. Binary name to be launched.

targetDirectoriesList=""
minimumQuantityOfDirsToBeCompared="1" # You may load only one directory for comparision, and selec another one in external utility UI.
maximumQuantityOfDirsToBeCompared="2"

minPanelNumber="1" # Panel's coordinate system ancors.
maxPanelNumber="4"

errorState=0 # Zero is OK.
errorMisc="1"

quantityOfFoundDirectories=0 # Quantity of to be choosen for comparision.


function validatePanelNumber {
    local panelNumber=${1}
    if [ ${panelNumber} -lt ${minPanelNumber} ] \
        || [ ${panelNumber} -gt ${maxPanelNumber} ]
    then
        echo "ERROR:${0}:${LINENO}: Panel number '${panelNumber}' is out of range." >&2
        exit ${errorMisc}
    fi
}

function getDirNamesOnPanel {
    local panelNumberList=(${@})
    local panelNumberValue=""
    local targetNameFromPanel=""
    local objectNameAsString=""
    local arrayLength=""
    local targetNameFromPanelIdx=""
    local argListIdx=""

    for (( argListIdx=0 ; \
            argListIdx<${#panelNumberList[@]} ; \
            argListIdx++ ))
    do
        panelNumberValue="${panelNumberList[argListIdx]}"
        validatePanelNumber "${panelNumberValue}"
        objectNameAsString="#fm_panel${panelNumberValue}_files[@]"
        arrayLength="$( eval echo "\${${objectNameAsString}}" )"
        objectNameAsString=""
        for (( targetNameFromPanelIdx=0 ; \
                targetNameFromPanelIdx<arrayLength ; \
                targetNameFromPanelIdx++ ))
        do
            objectNameAsString="fm_panel${panelNumberValue}_files[targetNameFromPanelIdx]"
            targetNameFromPanel="${!objectNameAsString}"
            [ ! -d "${targetNameFromPanel}" ] \
                && continue
            (( quantityOfFoundDirectories++ ))
            [ "${quantityOfFoundDirectories}" -gt "${maximumQuantityOfDirsToBeCompared}" ] \
                && break
            targetDirectoriesList[ $(( ${quantityOfFoundDirectories} - 1 )) ]="${targetNameFromPanel}"
        done
    done
    return ${quantityOfFoundDirectories}
}

function getDirNamesToBeCompared {
    local quantityOfFoundTargetDirs=""
    local activePanel=""
    
    local returnCodeSuccess="0"
    local returnCodeErrorMisc="1"
    
    activePanel="${fm_panel}"
    
    getDirNamesOnPanel "${activePanel}"
    quantityOfFoundTargetDirs="${?}"

    if [ ${quantityOfFoundTargetDirs} -lt ${maximumQuantityOfDirsToBeCompared} ]
    then
        case "${activePanel}" in
        1)
            getDirNamesOnPanel 2 3 4
        ;;
        2)
            getDirNamesOnPanel 1 3 4
        ;;
        3)
            getDirNamesOnPanel 4 1 2
        ;;
        4)
            getDirNamesOnPanel 3 1 2
        ;;
        *)
            return ${returnCodeErrorMisc}
        esac
    fi
    
    [ ${quantityOfFoundTargetDirs} -lt ${minimumQuantityOfDirsToBeCompared} ] \
        && return ${returnCodeErrorMisc}
    
    return ${returnCodeSuccess}
}

#
 #
# #
 #
#

if getDirNamesToBeCompared ; then
    nohup "${guiCompareUtilityBin}" "${targetDirectoriesList[@]}" >/dev/null 2>/dev/null &
else
    echo "Did you select any _directory_ on any panel?" >&2
    errorState=${errorMisc}
fi

exit ${errorState}

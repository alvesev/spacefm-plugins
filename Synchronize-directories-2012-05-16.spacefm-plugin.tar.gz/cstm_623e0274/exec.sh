#!/bin/bash

##
#
#   Copyright 2012 Alex Vesev
#   
#   This script is a tool to compare files or directories.
#
#   This script is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
# 
#   This script is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
# 
#   You should have received a copy of the GNU General Public License
#   along with this script. If not, see <http://www.gnu.org/licenses/>.
#   
##

${fm_import} # Import file manager variables.

declare    guiCompareUtilityBin="komparator4" # GUI tool to be used for comparision. Binary name to be launched.

declare -a targetDirectoriesList[0]=""
declare -a currentDirectoriesOnPanelsList=""
# There is dynamicaly generated set of names
#     selectedDirectoriesOnPanel_${N}_List=""

declare -r minimumQuantityOfDirsToBeCompared="1" # You may load only one directory for comparision, and select another one in external utility UI.
declare -r maximumQuantityOfDirsToBeCompared="2"

declare -r minPanelNumber="1" # Panel's coordinate system ancors.
declare -r maxPanelNumber="4"

declare    errorState="0" # Zero is OK.
declare -r errorMisc="1"

function initialiseIt() {
    local idx=""
    for (( idx=${minPanelNumber} ; idx<=${maxPanelNumber} ; idx++ )) ; do
        currentDirectoriesOnPanelsList[idx]="${fm_pwd_panel[idx]}"
    done
}

function validatePanelNumber {
    local panelNumber=${1}
    if [ ${panelNumber} -lt ${minPanelNumber} ] \
        || [ ${panelNumber} -gt ${maxPanelNumber} ]
    then
        echo "ERROR:${0}:${LINENO}: Panel number '${panelNumber}' is out of range." >&2
        exit ${errorMisc}
    fi
}

function getDirNamesOnPanels {
    local panelNumberList=("${@}")
    local panelNumberValue=""
    local nameFromPanel=""
    local objectNameAsString=""
    local arrayLength=""
    local choosenNameFromPanelIdx=""
    local quantityOfFoundDirectories=""
    local quantityOfPickedUpDirectories=""
    local onPanelIdx=""

    # Obtain separate lists of selected directories, one list per panel.
    quantityOfFoundDirectories=0
    for panelNumberValue in "${panelNumberList[@]}" ; do

        # Visibility check
        [ -z "${fm_pwd_panel[panelNumberValue]}" ] \
            && continue

        validatePanelNumber "${panelNumberValue}" # ?!
        
        choosenNameFromPanelIdx=0
        objectNameAsString="fm_panel${panelNumberValue}_files[@]"
        for nameFromPanel in "${!objectNameAsString}" ; do
            [ "${choosenNameFromPanelIdx}" -ge "${maximumQuantityOfDirsToBeCompared}" ] \
                && break
            [ ! -d "${nameFromPanel}" ] \
                && continue

            objectNameAsString=""
            objectNameAsString="selectedDirectoriesOnPanel${panelNumberValue}List[choosenNameFromPanelIdx]"
            eval ${objectNameAsString}=\"${nameFromPanel}\"
            (( choosenNameFromPanelIdx++ ))
            (( quantityOfFoundDirectories++ ))
        done
    done

    # Pick up directories names from list of found.
    # And substitude panels current directory names if nothing selected.
    quantityOfPickedUpDirectories=0
    for panelNumberValue in "${panelNumberList[@]}" ; do

        # Visibility check
        [ -z "${fm_pwd_panel[panelNumberValue]}" ] \
            && continue

        objectNameAsString=""
        objectNameAsString="#selectedDirectoriesOnPanel${panelNumberValue}List[@]"
        eval arrayLength=\"\${${objectNameAsString}}\"
        
        if [ ${arrayLength} == 0 ] \
            && [ ${quantityOfFoundDirectories} -lt ${maximumQuantityOfDirsToBeCompared} ] \
            && [ ${quantityOfPickedUpDirectories} -lt ${maximumQuantityOfDirsToBeCompared} ]
        then
            if [ ${quantityOfPickedUpDirectories} == 0 ] \
                    || \
                    [ ${quantityOfPickedUpDirectories} != 0 ] \
                    && [ "${targetDirectoriesList[quantityOfPickedUpDirectories-1]}" \
                            != \
                            "${currentDirectoriesOnPanelsList[panelNumberValue]}" ] 
            then
                targetDirectoriesList[quantityOfPickedUpDirectories]="${currentDirectoriesOnPanelsList[panelNumberValue]}"
                (( quantityOfPickedUpDirectories++ ))
                continue
            fi
        fi
        
        for (( onPanelIdx=0 ; \
                onPanelIdx<${arrayLength} ; \
                onPanelIdx++ ))
        do
            objectNameAsString=""
            objectNameAsString="selectedDirectoriesOnPanel${panelNumberValue}List[onPanelIdx]"
            targetDirectoriesList[quantityOfPickedUpDirectories]=${!objectNameAsString}
            (( quantityOfPickedUpDirectories++ ))
            [ ${quantityOfPickedUpDirectories} -ge ${maximumQuantityOfDirsToBeCompared} ] \
                && return ${quantityOfPickedUpDirectories}
        done
    done

    return ${quantityOfPickedUpDirectories}
}

function getDirNamesToBeCompared {
    local quantityOfFoundTargetDirs=""
    local activePanel=""
    
    local returnCodeSuccess="0"
    local returnCodeErrorMisc="1"
    
    activePanel="${fm_panel}"
    
    case "${activePanel}" in
    1)
        getDirNamesOnPanels 1 2 3 4
    ;;
    2)
        getDirNamesOnPanels 2 1 3 4
    ;;
    3)
        getDirNamesOnPanels 3 4 1 2
    ;;
    4)
        getDirNamesOnPanels 4 3 1 2
    ;;
    *)
        return ${returnCodeErrorMisc}
    ;;
    esac
    
    return ${returnCodeSuccess}
}

#
 #
# #
 #
#

initialiseIt
if getDirNamesToBeCompared ; then
    nohup "${guiCompareUtilityBin}" "${targetDirectoriesList[@]}" >/dev/null 2>/dev/null &
else
    echo "ERROR:${0}:${LINENO}: Failed to obtain names to be compared." >&2
    errorState=${errorMisc}
fi

exit ${errorState}
